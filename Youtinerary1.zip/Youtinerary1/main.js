var request = require('request');
var OAuth   = require('oauth-1.0a');

var name = 1;
var dostuff = 1;
var like = 1;
var nolike = 1;
var zipcode = 1;

var oauth = OAuth({
    consumer: {
        public: 'OUVsxo2Gmk9D3IIpB1QsZA',
        secret: 'tjm13cnfMoUeDpEpSNRHHokircc'
    },
    signature_method: 'HMAC-SHA1'
});

var token = {
    public: 'fap0ouB7cjRHvXqhgsNyQ82OzZXkNh5T',
    secret: 'VGAT1nJh2PtkbRGT8Md7YI_3BMI'
};

var request_data = {
    url: "https://www.api.yelp.com/v2/search?term=" + like + "&location=" + name.replace(" ", "+") + zipcode + "&limit=5" + "",
    method: 'POST',
    data: {
        format: "json"
    }
};

function exportToCsv() {
   name = $("#name-input").val();
   dostuff = $("#do-input").val();
   like =  $("#like-input").val();
   nolike =  $("#dislike-input").val();
   zipcode = $("#zipcode-input").val();
   console.log(name);
}

var meetupsstring = "https://api.meetup.com1/find/groups2?zip=" + zipcode + "&radius=3";

$("#b").click(exportToCsv);

$.ajax({
   url: meetupsstrings,
   
   error: function() {
       // put error code here
   },
      
   dataType: "json",

   success: function() {
       var $description = $('<p>').text(data.results[4].description);
       var $links = $('<p>').text(data.results[2].link);
       $.ajax({
           url: request_data.url,
           type: request_data.method,
            data: oauth.authorize(request_data, token)
       }).done(function(data) {
            // put var assignments here
       });
   },
   
   type: "GET"
});